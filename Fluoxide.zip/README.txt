 ███████████ ████                                   ███      █████         
░░███░░░░░░█░░███                                  ░░░      ░░███          
 ░███   █ ░  ░███  █████ ████  ██████  █████ █████ ████   ███████   ██████ 
 ░███████    ░███ ░░███ ░███  ███░░███░░███ ░░███ ░░███  ███░░███  ███░░███
 ░███░░░█    ░███  ░███ ░███ ░███ ░███ ░░░█████░   ░███ ░███ ░███ ░███████ 
 ░███  ░     ░███  ░███ ░███ ░███ ░███  ███░░░███  ░███ ░███ ░███ ░███░░░  
 █████       █████ ░░████████░░██████  █████ █████ █████░░████████░░██████ 
░░░░░       ░░░░░   ░░░░░░░░  ░░░░░░  ░░░░░ ░░░░░ ░░░░░  ░░░░░░░░  ░░░░░░  
This is a MSVC safe gdi malware, there is no destructive code. you can run it on your real computer. 
1280x720 is the best resolution for the malware, 
Requirements(or however its spelled like, english is not my first language братан):
Windows (Any version XP-11), or use a VM
C++ REDIST installed (i honestly feel like its installed on every PC)
Massive Epilepsy Warning:
Please do not run this when you have epilepsy, i do not want to kill anyone. 
either lower your brightness or dont run it at all